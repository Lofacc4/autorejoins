package rejoin.backup;
import java.nio.file.*;
import java.util.*;
public class ServerBackup {
    private static final Path backupDir = Path.of("config","auto-rejoin","backups");
    private static final Path watchedDir = Path.of("config","auto-rejoin","servers");
    public static void ensureDirectory() {
        try { Files.createDirectories(backupDir); } catch (Exception ignored) {}
        try { Files.createDirectories(watchedDir); } catch (Exception ignored) {}
    }
    public static List<String> listBackups() {
        List<String> result = new ArrayList<>();
        try (var stream = Files.list(backupDir)) {
            stream.filter(f -> f.toString().endsWith(".dat")).forEach(f -> result.add(f.getFileName().toString()));
        } catch (Exception ignored) {}
        return result;
    }
    public static boolean createBackup(String name, String data) {
        try { Files.writeString(backupDir.resolve(name + ".dat"), data); return true; } catch (Exception ignored) { return false; }
    }
    public static String loadBackup(String name) {
        try { return Files.readString(backupDir.resolve(name + ".dat")); } catch (Exception ignored) { return null; }
    }
    public static void cleanOld(int keepLast) {
        try {
            var files = new ArrayList<>(Files.list(backupDir).sorted((a, b) -> {
                try { return Files.getLastModifiedTime(b).compareTo(Files.getLastModifiedTime(a)); } catch (Exception e) { return 0; }
            }).toList());
            for (int i = keepLast; i < files.size(); i++) { try { Files.delete(files.get(i)); } catch (Exception ignored) {} }
        } catch (Exception ignored) {}
    }
}
