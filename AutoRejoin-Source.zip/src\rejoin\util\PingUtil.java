package rejoin.util;
public class PingUtil {
    private static int calibration = 0;
    public static void calibrate() { calibration = 0; }
    public static int estimatePing(String address) { return 20 + calibration; }
    public static void setCalibration(int c) { calibration = c; }
    public static int getCalibration() { return calibration; }
}
