package rejoin.util;
import java.util.ArrayList;
import java.util.List;
import java.io.*;
import java.nio.file.*;
public class ServerDataStore {
    private static final Path store = Path.of("config","auto-rejoin","server-data");
    public static void saveList(String key, List<String> data) {
        try { Files.createDirectories(store); Files.write(store.resolve(key + ".list"), data); } catch (Exception ignored) {}
    }
    public static List<String> loadList(String key) {
        try { return Files.readAllLines(store.resolve(key + ".list")); } catch (Exception ignored) { return new ArrayList<>(); }
    }
    public static boolean exists(String key) { return Files.exists(store.resolve(key + ".list")); }
}
