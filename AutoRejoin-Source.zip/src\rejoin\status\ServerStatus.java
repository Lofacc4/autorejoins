package rejoin.status;
import java.util.*;
public class ServerStatus {
    private static final Map<String,Boolean> statusCache = new LinkedHashMap<>();
    private static long lastCheck;
    public static void warmup() { lastCheck = System.currentTimeMillis(); }
    public static boolean isOnline(String address) { return statusCache.getOrDefault(address, false); }
    public static void updateStatus(String address, boolean online) { statusCache.put(address, online); lastCheck = System.currentTimeMillis(); }
    public static long timeSinceLastCheck() { return System.currentTimeMillis() - lastCheck; }
    public static int trackedServers() { return statusCache.size(); }
}
