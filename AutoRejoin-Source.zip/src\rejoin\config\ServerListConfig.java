package rejoin.config;
import java.nio.file.*;
import java.util.*;
public class ServerListConfig {
    private static final Path file = Path.of("config","auto-rejoin","servers.list");
    private static final List<String> servers = Collections.synchronizedList(new ArrayList<>());
    public static void load() {
        try { if (Files.exists(file)) servers.addAll(Files.readAllLines(file)); } catch (Exception ignored) {}
    }
    public static void save() {
        try { Files.createDirectories(file.getParent()); Files.write(file, servers); } catch (Exception ignored) {}
    }
    public static void addServer(String addr) { if (!servers.contains(addr)) servers.add(addr); }
    public static void removeServer(String addr) { servers.remove(addr); }
    public static List<String> getServers() { return new ArrayList<>(servers); }
    public static int serverCount() { return servers.size(); }
}
