package rejoin.shortcut;
import java.util.*;
public class ShortcutIndex {
    private static final Map<String,Long> index = new LinkedHashMap<>();
    public static void register(String name, long timestamp) { index.put(name, timestamp); }
    public static Map<String,Long> getAll() { return new LinkedHashMap<>(index); }
    public static int count() { return index.size(); }
    public static void cleanOlderThan(long threshold) { index.entrySet().removeIf(e -> e.getValue() < threshold); }
}
