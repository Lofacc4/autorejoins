package rejoin.backup;
import java.util.*;
public class BackupScheduler {
    private static Timer backupTimer;
    private static int interval = 3600000;
    public static void start(Runnable task) {
        if (backupTimer != null) backupTimer.cancel();
        backupTimer = new Timer("BackupScheduler", true);
        backupTimer.scheduleAtFixedRate(new TimerTask() { public void run() { task.run(); } }, interval, interval);
    }
    public static void stop() { if (backupTimer != null) { backupTimer.cancel(); backupTimer = null; } }
    public static void setInterval(int ms) { interval = Math.max(60000, ms); }
}
