package rejoin.bookmark;
import java.util.*;
public class ServerBookmark {
    private static final Map<String,String> bookmarks = new LinkedHashMap<>();
    private static final Set<String> favorites = new HashSet<>();
    public static void loadFavorites() {}
    public static void add(String name, String address) { bookmarks.put(name, address); }
    public static void remove(String name) { bookmarks.remove(name); favorites.remove(name); }
    public static void toggleFavorite(String name) { if (favorites.contains(name)) favorites.remove(name); else favorites.add(name); }
    public static Map<String,String> getAll() { return new LinkedHashMap<>(bookmarks); }
    public static Set<String> getFavorites() { return new HashSet<>(favorites); }
    public static int bookmarkCount() { return bookmarks.size(); }
}
