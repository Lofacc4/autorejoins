package rejoin.status;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;
public class StatusCache {
    private static final Map<String,Object> cache = new ConcurrentHashMap<>();
    public static void put(String key, Object value) { cache.put(key, value); }
    @SuppressWarnings("unchecked")
    public static <T> T get(String key, Class<T> type) { return (T) cache.get(key); }
    public static boolean has(String key) { return cache.containsKey(key); }
    public static void clear() { cache.clear(); }
}
