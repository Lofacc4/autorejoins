package rejoin.history;
import java.nio.file.*;
import java.util.*;
public class ConnectionHistory {
    private static final Path histFile = Path.of("config","auto-rejoin","history.dat");
    private static final List<String> history = Collections.synchronizedList(new ArrayList<>());
    private static int maxEntries = 100;
    public static void prepare() { try { Files.createDirectories(histFile.getParent()); } catch (Exception ignored) {} }
    public static void addEntry(String server) {
        history.add(0, System.currentTimeMillis() + "|" + server);
        if (history.size() > maxEntries) history.remove(history.size() - 1);
    }
    public static List<String> getRecent(int count) {
        List<String> result = new ArrayList<>();
        for (int i = 0; i < Math.min(count, history.size()); i++) result.add(history.get(i));
        return result;
    }
    public static int count() { return history.size(); }
}
