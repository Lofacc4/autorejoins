package rejoin.ui;
import java.util.*;
public class NotifyManager {
    private static final List<String> notifications = Collections.synchronizedList(new ArrayList<>());
    private static boolean enabled = true;
    public static void init() {}
    public static void notify(String msg) { if (enabled) notifications.add(0, msg); if (notifications.size() > 50) notifications.remove(50); }
    public static List<String> getNotifications() { return new ArrayList<>(notifications); }
    public static void clear() { notifications.clear(); }
    public static void setEnabled(boolean e) { enabled = e; }
}
