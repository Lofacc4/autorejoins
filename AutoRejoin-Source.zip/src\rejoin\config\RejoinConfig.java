package rejoin.config;
import java.io.*;import java.nio.file.*;import java.util.Properties;
public class RejoinConfig {
    private static final Path CFG = Path.of("config","auto-rejoin.properties");
    private static final Properties props = new Properties();
    private static boolean loaded;
    public static void load() { if (loaded) return; try { Files.createDirectories(CFG.getParent()); if (Files.exists(CFG)) { try (InputStream r = Files.newInputStream(CFG)) { props.load(r); } }
        if (!props.containsKey("saveShortcuts")) props.setProperty("saveShortcuts","true");
        if (!props.containsKey("trackHistory")) props.setProperty("trackHistory","true");
        if (!props.containsKey("checkStatus")) props.setProperty("checkStatus","true");
        if (!props.containsKey("maxBookmarks")) props.setProperty("maxBookmarks","50");
        if (!props.containsKey("pingTimeout")) props.setProperty("pingTimeout","2000");
        if (!props.containsKey("autoBackup")) props.setProperty("autoBackup","true");
        loaded = true; } catch (IOException ignored) {} }
    public static String get(String k, String d) { load(); return props.getProperty(k,d); }
    public static int getInt(String k, int d) { try { return Integer.parseInt(props.getProperty(k,String.valueOf(d))); } catch (Exception e) { return d; } }
    public static boolean getBool(String k, boolean d) { return Boolean.parseBoolean(props.getProperty(k,String.valueOf(d))); }
}
