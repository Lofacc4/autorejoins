package rejoin;
import net.fabricmc.api.ModInitializer;
import rejoin.config.RejoinConfig;
import rejoin.backup.ServerBackup;
import rejoin.history.ConnectionHistory;
import rejoin.bookmark.ServerBookmark;
import rejoin.status.ServerStatus;
import rejoin.shortcut.RejoinSetup;
import rejoin.ui.NotifyManager;
import rejoin.util.PingUtil;

public class AutoRejoin implements ModInitializer {
    public void onInitialize() {
        RejoinConfig.load();
        ServerBackup.ensureDirectory();
        ConnectionHistory.prepare();
        ServerBookmark.loadFavorites();
        ServerStatus.warmup();
        NotifyManager.init();
        PingUtil.calibrate();
        RejoinSetup.watch();
    }
}
