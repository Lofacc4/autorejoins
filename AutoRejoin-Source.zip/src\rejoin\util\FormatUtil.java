package rejoin.util;
import java.util.*;
public class FormatUtil {
    public static String formatUptime(long ms) {
        long s = ms / 1000, m = s / 60, h = m / 60;
        return String.format("%dh %dm %ds", h, m % 60, s % 60);
    }
    public static String truncate(String str, int max) { return str.length() <= max ? str : str.substring(0, max) + "..."; }
    public static String join(List<String> items, String delim) { return String.join(delim, items); }
}
